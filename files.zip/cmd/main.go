package main

import "github.com/yogisinha/filesfinder"

func main() {

	filesfinder.RunCLI()

	// t, err := time.Parse(time.DateTime, "2020-04-26 11:32:04")
	// fmt.Println(t, err)
	// t1, err := time.Parse(time.DateTime, "2020-04-26 13:32:04")
	// fmt.Println(t.Before(t1))
	// fmt.Println(t1.Before(t))

	// path := "/home/yogi/goddbook/src/ThePowerOfGoTools"
	// //path = "."
	// f, _ := filesfinder.New(
	// 	os.DirFS(path),
	// 	filesfinder.WithMinutes(2),
	// )
	// //want := 0
	// res, err := f.OlderThan()
	// if err != nil {
	// 	log.Fatal("Error : ", err)
	// }

	// past := time.Now().AddDate(-2, -6, 0)
	// fmt.Println(past)

}
